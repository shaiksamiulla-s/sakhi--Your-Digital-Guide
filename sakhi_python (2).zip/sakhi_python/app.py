"""Sakhi – your digital guide  (Python / Flask version)

Serves the same mobile UI and adds a real backend:
  * mobile-number login with OTP (rate-limited, expiring, hashed in the DB)
  * per-user document locker + saved location, stored in SQLite
Run:  pip install -r requirements.txt   then   python app.py
"""
import hashlib, hmac, json, os, re, secrets, sqlite3, time
from flask import Flask, jsonify, request, send_from_directory, session, g

BASE = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.environ.get("SAKHI_DB", os.path.join(BASE, "sakhi.db"))
SECRET = os.environ.get("SAKHI_SECRET") or secrets.token_hex(32)   # set SAKHI_SECRET so logins survive restarts
DEMO = os.environ.get("SAKHI_DEMO", "1") == "1"   # 1 = show OTP on screen + console. Set 0 when a real SMS provider is wired in.
OTP_TTL, OTP_GAP, OTP_TRIES = 300, 30, 5           # seconds valid / seconds between sends / max wrong tries

app = Flask(__name__, static_folder="static", static_url_path="/static")
app.secret_key = SECRET
app.config.update(MAX_CONTENT_LENGTH=8 * 1024 * 1024,        # locker photos are small JPEGs inside the JSON
                  SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax",
                  PERMANENT_SESSION_LIFETIME=60 * 60 * 24 * 30)


# ---------- database ----------
def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.executescript("""
            CREATE TABLE IF NOT EXISTS users(phone TEXT PRIMARY KEY, data TEXT NOT NULL DEFAULT '{}');
            CREATE TABLE IF NOT EXISTS otps(phone TEXT PRIMARY KEY, code_hash TEXT, expires REAL, sent REAL, tries INTEGER);""")
    return g.db


@app.teardown_appcontext
def close_db(_):
    d = g.pop("db", None)
    if d:
        d.close()


# ---------- OTP ----------
def hash_otp(phone, code):
    return hmac.new(SECRET.encode(), f"{phone}:{code}".encode(), hashlib.sha256).hexdigest()


def send_sms(phone, code):
    """Plug your SMS provider in here (MSG91, Twilio, Fast2SMS, Firebase...).
    Example with Twilio:  Client(SID, TOKEN).messages.create(to="+91"+phone, from_=FROM, body=f"Sakhi code: {code}")"""
    print(f"[Sakhi] OTP for {phone}: {code}")


@app.post("/api/otp/send")
def otp_send():
    phone = str((request.get_json(silent=True) or {}).get("phone", "")).strip()
    if not re.fullmatch(r"[6-9]\d{9}", phone):
        return jsonify(error="badPh"), 400
    row = db().execute("SELECT sent FROM otps WHERE phone=?", (phone,)).fetchone()
    if row and time.time() - row["sent"] < OTP_GAP:
        return jsonify(error="wait"), 429
    code = f"{secrets.randbelow(9000) + 1000}"
    db().execute("INSERT OR REPLACE INTO otps VALUES(?,?,?,?,0)",
                 (phone, hash_otp(phone, code), time.time() + OTP_TTL, time.time()))
    db().commit()
    send_sms(phone, code)
    return jsonify(ok=True, **({"demo_otp": code} if DEMO else {}))


@app.post("/api/otp/verify")
def otp_verify():
    j = request.get_json(silent=True) or {}
    phone, code = str(j.get("phone", "")), str(j.get("otp", "")).strip()
    row = db().execute("SELECT * FROM otps WHERE phone=?", (phone,)).fetchone()
    if not row or time.time() > row["expires"] or row["tries"] >= OTP_TRIES:
        return jsonify(error="badOtp"), 400
    if not hmac.compare_digest(row["code_hash"], hash_otp(phone, code)):
        db().execute("UPDATE otps SET tries=tries+1 WHERE phone=?", (phone,))
        db().commit()
        return jsonify(error="badOtp"), 400
    db().execute("DELETE FROM otps WHERE phone=?", (phone,))
    db().execute("INSERT OR IGNORE INTO users(phone) VALUES(?)", (phone,))
    db().commit()
    session.clear()
    session.permanent = True
    session["phone"] = phone
    return jsonify(ok=True)


@app.post("/api/logout")
def logout():
    session.clear()
    return jsonify(ok=True)


# ---------- user data: locker + location ----------
def current_phone():
    return session.get("phone")


@app.get("/api/me")
def me_get():
    phone = current_phone()
    if not phone:
        return jsonify(error="auth"), 401
    row = db().execute("SELECT data FROM users WHERE phone=?", (phone,)).fetchone()
    data = json.loads(row["data"]) if row else {}
    return jsonify(phone=phone, locker=data.get("locker", {}), loc=data.get("loc"))


@app.put("/api/me")
def me_put():
    phone = current_phone()
    if not phone:
        return jsonify(error="auth"), 401
    j = request.get_json(silent=True) or {}
    locker = {k: {"has": bool(v.get("has")),
                  **({"img": v["img"]} if str(v.get("img", "")).startswith("data:image/jpeg;base64,") else {})}
              for k, v in (j.get("locker") or {}).items()
              if k in ("ration", "aadhaar", "bank", "birth") and isinstance(v, dict)}
    loc = j.get("loc")
    if not (isinstance(loc, dict) and all(isinstance(loc.get(a), (int, float)) for a in ("lat", "lng"))):
        loc = None
    db().execute("INSERT OR REPLACE INTO users VALUES(?,?)", (phone, json.dumps({"locker": locker, "loc": loc})))
    db().commit()
    return jsonify(ok=True)


# ---------- the app itself ----------
@app.get("/")
def index():
    return send_from_directory(app.static_folder, "index.html")


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 5000)), debug=os.environ.get("FLASK_DEBUG") == "1")
